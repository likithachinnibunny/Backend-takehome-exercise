import argparse
import csv
from pubmed_papers.fetcher import fetch_pubmed_data
from pubmed_papers.filters import extract_company_names
from pubmed_papers.utils import extract_email

def main():
    parser = argparse.ArgumentParser(description="PubMed paper fetcher")
    parser.add_argument("query", help="PubMed search query")
    parser.add_argument("-f", "--file", help="Output CSV filename")
    parser.add_argument("-d", "--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    results = fetch_pubmed_data(args.query, debug=args.debug)

    rows = []
    for result in results:
        rows.append({
            "PubmedID": result.get("id"),
            "Title": "Sample Title",  # Replace with real parsed data
            "Publication Date": "YYYY-MM-DD",
            "Non-academic Author(s)": "Dr. Smith",
            "Company Affiliation(s)": "Example Pharma",
            "Corresponding Author Email": "example@example.com"
        })

    if args.file:
        with open(args.file, mode='w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    else:
        for row in rows:
            print(row)

if __name__ == "__main__":
    main()
