from pubmed_papers.fetcher import fetch_pubmed_data

def test_fetch_pubmed_data():
    results = fetch_pubmed_data("covid", debug=True)
    assert isinstance(results, list)
