from typing import Tuple, List
import re

def is_non_academic(affiliation: str) -> bool:
    academic_keywords = ["university", "institute", "college", "school", "hospital", "lab"]
    return not any(k in affiliation.lower() for k in academic_keywords)

def extract_company_names(affiliations: List[str]) -> List[str]:
    return [a for a in affiliations if is_non_academic(a)]
