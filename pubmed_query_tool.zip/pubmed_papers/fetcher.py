from typing import List, Dict
import requests

def fetch_pubmed_data(query: str, debug: bool = False) -> List[Dict]:
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
    search_url = f"{base_url}esearch.fcgi?db=pubmed&term={query}&retmax=20&retmode=json"
    if debug:
        print(f"Search URL: {search_url}")
    response = requests.get(search_url)
    ids = response.json().get("esearchresult", {}).get("idlist", [])

    if not ids:
        return []

    id_str = ",".join(ids)
    fetch_url = f"{base_url}efetch.fcgi?db=pubmed&id={id_str}&retmode=xml"
    if debug:
        print(f"Fetch URL: {fetch_url}")
    fetch_response = requests.get(fetch_url)
    return [
        {"raw_xml": fetch_response.text, "id": i} for i in ids
    ]
