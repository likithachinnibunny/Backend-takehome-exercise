# PubMed Query Tool

## Description
A Python CLI tool to search PubMed papers, identify authors affiliated with biotech companies, and export results to CSV.

## Installation
```bash
git clone https://github.com/yourusername/pubmed-query-tool.git
cd pubmed-query-tool
poetry install
```

## Usage
```bash
poetry run get-papers-list "cancer immunotherapy" -f output.csv
```

## Features
- Fetch papers via PubMed API
- Identify non-academic authors
- Save results to CSV

## Dependencies
- [requests](https://pypi.org/project/requests/)

## License
MIT
